// Copyright 2011-2012 Renato Tegon Forti
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt
// or copy at http://www.boost.org/LICENSE_1_0.txt)

// For more information, see http://www.boost.org

#include <boost/test/minimal.hpp>
#include <boost/application/application.hpp>

using namespace boost::application;

// Unit Tests


class my_application_functor_class
{
public:
   int operator()(const std::vector< application_ctrl::string_type >& args, 
      boost::application::application_ctrl& ctrl)
   {
      // environ var tests

      application_ctrl::string_type var_name = "BOOST_APPLICATION_MYAPP", var_value = "Hello APP!";

      BOOST_CHECK(ctrl.set_environ_var(environ_variable(var_name), environ_variable(var_value)) == false);
      BOOST_CHECK(ctrl.has_environ_var(environ_variable(var_name)));
      BOOST_CHECK(ctrl.environ_var(environ_variable(var_name)) == environ_variable(var_value).get());
      BOOST_CHECK(ctrl.unset_environ_var(environ_variable(var_name)) == false);
      
      return 0;
   }
};

int test_main(int argc, char** argv)
{
   BOOST_CHECK(application< my_application< my_application_functor_class > >( args(argc, argv) )() == 0);
   return 0;
}
