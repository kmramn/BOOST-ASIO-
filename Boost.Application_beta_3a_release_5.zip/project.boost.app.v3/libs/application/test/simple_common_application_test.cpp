// Copyright 2011-2012 Renato Tegon Forti
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt
// or copy at http://www.boost.org/LICENSE_1_0.txt)

// For more information, see http://www.boost.org

#include <boost/test/minimal.hpp>
#include <boost/application/application.hpp>

using namespace boost::application;

// Unit Tests

class my_application_functor_class
{
public:
   int operator()(const std::vector< application_ctrl::string_type >& args, 
      boost::application::application_ctrl& ctrl)
   { 
      return 0;
   }
};

int test_main(int argc, char** argv)
{
   BOOST_CHECK(application< my_application< my_application_functor_class > >( args(argc, argv) )() == 0);
   return 0;
}
