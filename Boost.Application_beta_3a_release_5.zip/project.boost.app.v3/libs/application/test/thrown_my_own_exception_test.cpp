// Copyright 2011-2013 Renato Tegon Forti
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt
// or copy at http://www.boost.org/LICENSE_1_0.txt)

// For more information, see http://www.boost.org

#include <boost/application/exceptions.hpp>

struct myexception : public boost::application::application_exception 
{ 
   myexception(const std::string& what, unsigned int error_code) 
     : boost::application::application_exception(what, error_code) {}
};


#define BOOST_APPLICATION_TROWN_MY_OWN_EXCEPTION throw myexception
#include <boost/application.hpp>

using namespace boost::application;
class my_application_functor_class
{
public:

   int operator()(const std::vector< application_ctrl::string_type >& args, 
      boost::application::application_ctrl& ctrl)
   {
      throw myexception("my_exception_4121", 4121);
      return 0;
   }

};

int main(int argc, char* argv[])
{
   try
   {
      return application<
         my_application< my_application_functor_class > 
      >( args(argc, argv))();
   }
   catch(const myexception &e)
   {
      BOOST_CHECK(e.code() == 4121);
   }
}

