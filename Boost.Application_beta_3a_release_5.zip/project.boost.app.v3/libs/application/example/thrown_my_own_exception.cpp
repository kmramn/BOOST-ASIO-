// Copyright 2011-2013 Renato Tegon Forti
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt
// or copy at http://www.boost.org/LICENSE_1_0.txt)

// For more information, see http://www.boost.org

#include "myexception.hpp"

using namespace boost::application;
namespace po = boost::program_options;

class my_application_functor_class
{
public:

   int operator()(const std::vector< application_ctrl::string_type >& args, 
      boost::application::application_ctrl& ctrl)
   {
      // service logic
	  throw myexception("my error", 4121);
	   
      ctrl.wait_for_termination_request();
      return 0;
   }

   int stop()
   {
      std::cout << "Stoping my application..." << std::endl;
      return 1;
   }

};

int main(int argc, char* argv[])
{
   try
   {
      return application<
         my_application< my_application_functor_class > 
      >( args(argc, argv))();
   }
   catch(const myexception &e)
   {
      std::cerr << e.what() << std::endl;
   }
}
