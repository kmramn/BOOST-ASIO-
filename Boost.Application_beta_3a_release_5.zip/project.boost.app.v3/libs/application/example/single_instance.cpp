// Copyright 2011-2012 Renato Tegon Forti
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt
// or copy at http://www.boost.org/LICENSE_1_0.txt)

// -----------------------------------------------------------------------------
// This example shows how to handle single instance application using
// boost application lib.
// -----------------------------------------------------------------------------

#define BOOST_ALL_DYN_LINK
#define BOOST_LIB_DIAGNOSTIC

#include <boost/uuid/string_generator.hpp>
#include <boost/application.hpp>

using namespace boost::application;

class my_application_functor_class
{
   
public:
   int operator()(const std::vector< application_ctrl::string_type >& args, 
      boost::application::application_ctrl& ctrl)
   {
      // my app logic
      std::cout << "operator" << std::endl;

      ctrl.wait_for_termination_request();
      return 0;
   }

   // Single Instance ID
   boost::uuids::uuid limit_single_instance(void)
   {
      std::cout << "limit_single_instance" << std::endl; 
	  
      boost::uuids::string_generator gen;
      boost::uuids::uuid app_uuid = gen("{9F66E4AD-ECA5-475D-8784-4BAA329EF9F1}");

      return app_uuid;
   }

   bool single_instance(boost::application::application_ctrl& ctrl)
   {
      std::cout << "single_instance" << std::endl; 
      std::cout << "aready an instance (" << boost::lexical_cast<std::string>(limit_single_instance()) << 
         ") running, exiting..." << std::endl;

      // If you return false single instance behaviour will be ignored.
      return  true;
   }
};

int main(int argc, char* argv[])
{
   return common_app<my_application_functor_class>( args(argc, argv) )();
   // Extended Class Interface :
   // return application< my_application< my_application_functor_class > >( args(argc, argv) )();
}

