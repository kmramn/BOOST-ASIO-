// Copyright 2011-2012 Renato Tegon Forti
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt
// or copy at http://www.boost.org/LICENSE_1_0.txt)

// For more information, see http://www.boost.org

// -----------------------------------------------------------------------------
// This example shows how to handle environ variables using 
// application_ctrl class.
// -----------------------------------------------------------------------------

#define BOOST_ALL_DYN_LINK
#define BOOST_LIB_DIAGNOSTIC

#include <boost/application.hpp>

using namespace boost::application;

class my_application_functor_class
{
public:
   int operator()(const std::vector< application_ctrl::string_type >& args, 
      boost::application::application_ctrl& ctrl)
   {
      // my app logic

      application_ctrl::string_type var_name = "BOOST_APPLICATION_MYAPP";
      application_ctrl::string_type var_value = "Hello APP!";

      std::cout 
         << "Define a new variable called: " 
         << var_name 
         << std::endl;

      std::cout 
         << ctrl.set_environ_var(environ_variable(var_name), environ_variable(var_value)) 
         << " (MUST BE 0)" 
         << std::endl;

      std::cout 
         << ctrl.has_environ_var(environ_variable(var_name)) 
         << " (MUST BE 1)" 
         << std::endl;

      std::string value = ctrl.environ_var(environ_variable(var_name));

      std::cout 
         << (ctrl.environ_var(environ_variable(var_name)) == environ_variable(var_value).get()) 
         << " (MUST BE 1) " 
         << value 
         << std::endl;

      std::cout 
         << ctrl.unset_environ_var(environ_variable(var_name)) 
         << " (MUST BE 0)" 
         << std::endl;

      std::cout 
         << ctrl.has_environ_var(environ_variable(var_name)) 
         << " (MUST BE 0)" 
         << std::endl;    

      // get environ
      std::map< application_ctrl::string_type, 
         application_ctrl::string_type > my = ctrl.environ_var_map();

      for(std::map< application_ctrl::string_type, 
          application_ctrl::string_type >::iterator iter = my.begin(); iter != my.end(); ++iter)
      {
         std::cout << iter->first << " :--> " << iter->second << std::endl;
      }

      return 0;
   }
};

int main(int argc, char* argv[])
{
   return application< my_application< my_application_functor_class > >( args(argc, argv) )();
}

