// -----------------------------------------------------------------------------
// common_tutorial_1.cpp :  examples that show how use 
// Boost.Application to make a simplest interactive (terminal) application
// -----------------------------------------------------------------------------

// Copyright 2011-2013 Renato Tegon Forti
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying 
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// Boost.Application Server all handlers
// 

// -----------------------------------------------------------------------------

#define BOOST_ALL_DYN_LINK
#define BOOST_LIB_DIAGNOSTIC

#include <iostream>
#include <fstream>

#include <boost/thread/thread.hpp>
#include <boost/uuid/string_generator.hpp>
#include <boost/application.hpp>

using namespace boost::application;

class myapp
{
public:

   void work_thread(boost::application::application_ctrl* ctrl)
   {
      // your application logic here!

      while(1) 
      {
         boost::this_thread::sleep(boost::posix_time::seconds(1));

          my_log_file_ << "work_thread [" << ctrl->elapsed_time() << 
             "s]" << std::endl;
      } 

   }

   int operator()(const std::vector< std::string >& args, 
      boost::application::application_ctrl& ctrl)
   {
      // your application logic here!
      // use ctrl to control your application...

      std::string logfile = ctrl.executable_path().string() + "/log.txt";
      
      my_log_file_.open(logfile.c_str());
      my_log_file_ << "Start Log..." << std::endl;

      // launch a work thread
      boost::thread thread(boost::bind(&myapp::work_thread, this, &ctrl));

      ctrl.wait_for_termination_request();

      return 0;
   }

   //
   // all handlers
   //

   boost::uuids::uuid limit_single_instance(void)
   {
      std::cout << "limit_single_instance" << std::endl; 
	  
      boost::uuids::string_generator gen;
      boost::uuids::uuid app_uuid = gen("{9266E4AD-ECA5-475D-8784-4BAA329EF9F1}");

      return app_uuid;
   }

   bool single_instance(boost::application::application_ctrl& ctrl)
   {
      std::cout << "single_instance" << std::endl; 
      std::cout << "aready an instance (" << boost::lexical_cast<std::string>(limit_single_instance()) << 
         ") running, exiting..." << std::endl;

      // If you return false single instance behaviour will be ignored.
      return  true;
   }

   int setup(boost::application::application_ctrl& ctrl)
   {
      // return 1 to exit, 0 to continue
      return 0;
   }

   int pause()
   {
      my_log_file_ << "Pause my application..." << std::endl;

      // return 1 to change state of application
      return 1;
   }
   
   int resume()
   {
      my_log_file_ << "Resume my application..." << std::endl;

      // return 1 to change state of application
      return 1;
   }

   int stop()
   {
      my_log_file_ << "Stoping my application..." << std::endl;
      my_log_file_.close();

      return 1;
   }

private:

   std::ofstream my_log_file_;

}; // myapp 

int main(int argc, char *argv[])
{
   return application< 
      application_type<server_application>, 
      accept_stop<yes>,                     // Accept stop (If True Windows and UNIX handle this!)
      accept_pause_and_resume<yes>,         // Accept pause and resume (Windows Only, ignored on UNIX)
      my_application< myapp > >( args(argc, argv))();
}

