// -----------------------------------------------------------------------------
// common_tutorial_1.cpp :  examples that show how use 
// Boost.Application to make a simplest interactive (terminal) application
// -----------------------------------------------------------------------------

// Copyright 2011-2013 Renato Tegon Forti
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying 
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// Boost.Application Common Tutorial 3 - Simplest Application (Terminal)
// using boost::program_options to handle user options, 
// wait_for_termination_request to wait stop signal and boost::thread
// 

// -----------------------------------------------------------------------------

#include <iostream>

#define BOOST_ALL_DYN_LINK
#define BOOST_LIB_DIAGNOSTIC

#include <boost/thread/thread.hpp>
#include <boost/program_options.hpp>
#include <boost/application.hpp>

using namespace boost::application;
namespace po = boost::program_options;

class myapp
{
public:

   void work_thread(boost::application::application_ctrl* ctrl)
   {
      while(1)
      {
         std::cout << m_ << " (" << 
            ctrl->elapsed_time() << "s)" << std::endl;
      }
   }

   int operator()(const std::vector< application_ctrl::string_type >& args, 
                  application_ctrl& ctrl)
   {
      // your application logic here!
      // use ctrl to get state of your application...

      po::variables_map vm;
      po::options_description desc;

      desc.add_options()
			(",h", "produce help message")
                  (",m", po::value<std::string>(), "set output message.")
			;

      po::store(po::parse_command_line(ctrl.argc(), ctrl.argv(), desc), vm);
      po::notify(vm);    

      if (vm.count("-h")) 
      {
		std::cout << desc << std::endl;
		return 0;
      }
      
      if (vm.count("-m")) 
      {
         m_ = vm["-m"].as<std::string>();
      }
      else
      {
          m_ = "Default Message...";
      }

      // launch a work thread
      boost::thread thread(boost::bind(&myapp::work_thread, this, &ctrl));

      ctrl.wait_for_termination_request();

      return 0;
   }
   
   // CTRL-C signal handler. 
   // Must return 1, in other case the app state don't will be
   // changed to "application_stoped"
   int stop()
   {
      std::cout << "Stoping my application..." << std::endl;
      return 1;
   }

private:

   // can be std::wstring or application_ctrl::string_type, 
   // that will be std::wstring id UNICODE is defined or std::string
   std::string m_;
   
}; // myapp 

int main(int argc, char *argv[])
{
   return application< my_application< myapp > >( args(argc, argv))();
}

