// Copyright 2011-2013 Renato Tegon Forti
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt
// or copy at http://www.boost.org/LICENSE_1_0.txt)

// For more information, see http://www.boost.org

// -----------------------------------------------------------------------------
// This example shows how to create a simplest server application, on windows
// this will be a windows service nad on unix/linux etc this will be a daemon.
//
// NOTES:
//
// On linux/unix you can end app send ctrl-c signal, like: kill -SIGINT <PID>
// On Windows, only stop service usnf SCM! Note that service must be installed! 
// Refer to sample : windows_service_setup.cpp to know how you can add setup 
// code to provide instalation to your windows service.
// -----------------------------------------------------------------------------


#define BOOST_ALL_DYN_LINK
#define BOOST_LIB_DIAGNOSTIC

#include <boost/application.hpp>

using namespace boost::application;

class my_application_functor_class
{
public:

   int operator()(const std::vector< std::string >& args, 
                  application_ctrl& ctrl)
   {
      // your application logic here!
      // use ctrl to get state of your application...

      do
      {
         std::cout << "In main, elapsed time: " << 
            ctrl.elapsed_time() << "s" << std::endl;

      } while (ctrl.state() == application_running);

      return 0;
   }
};

int main(int argc, char** argv)
{
   int ret = server_app<my_application_functor_class>( args(argc, argv) )();
   return ret;
}
