// Copyright 2011-2013 Renato Tegon Forti
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt
// or copy at http://www.boost.org/LICENSE_1_0.txt)

// For more information, see http://www.boost.org

#ifndef BOOST_APPLICATION_MYEXCEPTIONS_HPP
#define BOOST_APPLICATION_MYEXCEPTIONS_HPP

#include <boost/application/exceptions.hpp>

struct myexception : public boost::application::application_exception 
{ 
   myexception(const std::string& what, unsigned int error_code) 
     : boost::application::application_exception(what, error_code) {}
};


#define BOOST_APPLICATION_TROWN_MY_OWN_EXCEPTION throw myexception
#include <boost/application.hpp>

#endif // BOOST_APPLICATION_MYEXCEPTIONS_HPP
