// Copyright 2011-2013 Renato Tegon Forti
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt
// or copy at http://www.boost.org/LICENSE_1_0.txt)

// -----------------------------------------------------------------------------
// This example shows how to use boost program_options with boost application.
// 
// USE:
// 
// program_options[.exe] -m "test message"
// program_options[.exe] -h 
// -----------------------------------------------------------------------------

#define BOOST_ALL_DYN_LINK
#define BOOST_LIB_DIAGNOSTIC

#include <boost/uuid/string_generator.hpp>
#include <boost/application.hpp>
#include <boost/program_options.hpp>

namespace po = boost::program_options;
using namespace boost::application;

class my_application_functor_class
{
   
public:
   int operator()(const std::vector< application_ctrl::string_type >& args, 
      boost::application::application_ctrl& ctrl)
   {

      po::variables_map vm;
      po::options_description desc;

      desc.add_options()
         (",h", "produce help message")
         (",m", po::value<std::string>(), "set output message.")
         ;

      po::store(po::parse_command_line(ctrl.argc(), ctrl.argv(), desc), vm);
      po::notify(vm);    

      if (vm.count("-h")) 
      {
		std::cout << desc << std::endl;
		return 0;
      }
      
      if (vm.count("-m")) 
      {
         m_ = vm["-m"].as<std::string>();
      }
      else
      {
          m_ = "Default Message...";
      }

      do 
      {
         boost::this_thread::sleep(boost::posix_time::seconds(1));

         std::cout << m_ << " (" << ctrl.elapsed_time() << "s)" << std::endl;

      } while (ctrl.state() == boost::application::application_running);

      return 0;
   }

private:

   std::string m_;

};

int main(int argc, char* argv[])
{
   return application< my_application< my_application_functor_class > >( args(argc, argv) )();
}

