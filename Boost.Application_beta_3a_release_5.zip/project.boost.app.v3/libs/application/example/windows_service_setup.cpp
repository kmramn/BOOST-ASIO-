// Copyright 2011-2013 Renato Tegon Forti
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt
// or copy at http://www.boost.org/LICENSE_1_0.txt)

// -----------------------------------------------------------------------------
// This example shows how to use windows service setup module to provide a
// installation system to application using program_options
//
// [installation]
// windows_service_setup.exe -i
// /or/
// windows_service_setup.exe -i --name "My Service"
// windows_service_setup.exe -i --name "My Service"
// [check]
// windows_service_setup.exe -c
// /or/
// windows_service_setup.exe -c --name "My Service" 
// [unstalation]
// windows_service_setup.exe -u
// /or/
// windows_service_setup.exe -u --name "My Service" 
// 
// Note that when arg name are not priovided, the name will be the name of
// executable, in thiscase, service name will be: 'windows_service_setup'
// -----------------------------------------------------------------------------

#include <boost/application.hpp>
#include <boost/program_options.hpp>

using namespace boost::application;
namespace po = boost::program_options;

class my_application_functor_class
{
   
public:

   int setup(boost::application::application_ctrl& ctrl)
   {

   // provide setup for windows service   
#if defined(BOOST_WINDOWS_API)      

      // get our executable path name
      boost::filesystem::path executable_path_name = ctrl.executable_path_name();

      // define our simple installation schema options
      po::options_description install("service options");
      install.add_options()
         ("help", "produce a help message")
         (",i", "install service")
         (",u", "unistall service")
         (",c", "check service")
         ("name", po::value<std::string>()->default_value(ctrl.executable_name().stem().string()), "service name")
         ("display", po::value<std::string>()->default_value(""), "service display name (optional, installation only)")
         ("description", po::value<std::string>()->default_value(""), "service description (optional, installation only)")
         ;

         po::variables_map vm;
         po::store(po::parse_command_line(ctrl.argc(), ctrl.argv(), install), vm);
		 boost::system::error_code ec;

         if (vm.count("help")) 
         {
             std::cout << install << std::cout;
             return 1;
         }

         if (vm.count("-i")) 
         {
             install_windows_service(
               setup_arg(vm["name"].as<std::string>()), 
               setup_arg(vm["display"].as<std::string>()), 
               setup_arg(vm["description"].as<std::string>()), 
               setup_arg(executable_path_name)).install(ec);

             std::cout << ec.message() << std::endl;

             return 1;
         }

         if (vm.count("-u")) 
         {
            uninstall_windows_service(
               setup_arg(vm["name"].as<std::string>()), 
               setup_arg(executable_path_name)).uninstall(ec);
			   
			std::cout << ec.message() << std::endl;

            return 1;
         }

         if (vm.count("-c")) 
         {
             if(check_windows_service(setup_arg(vm["name"].as<std::string>())).exist(ec))
                std::cout << "Windows service '" 
                   << vm["name"].as<std::string>() 
                   << "' is aready installed!" 
                   << std::endl;
             else
                std::cout << "Windows service '" 
                   << vm["name"].as<std::string>() 
                   << "' is not installed!" 
                   << std::endl;

			 std::cout << ec.message() << std::endl;
             return 1;
         }
#endif

      // return 1 to exit, 0 to continue
      return 0;
   }
   

   int operator()(const std::vector< application_ctrl::string_type >& args, 
      boost::application::application_ctrl& ctrl)
   {
      // service logic

      ctrl.wait_for_termination_request();
      return 0;
   }
};

int main(int argc, char* argv[])
{
   return application<
      application_type<server_application>, 
      my_application< my_application_functor_class > 
   >( args(argc, argv))();
}

