// Copyright 2011-2013 Renato Tegon Forti
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt
// or copy at http://www.boost.org/LICENSE_1_0.txt)

// -----------------------------------------------------------------------------
// This example shows how to add both  application types support to application.
// [use]
// multi_application[.exe] -f (run as common/foreground)
// multi_application[.exe]    (run as server daemon) (default)
// -----------------------------------------------------------------------------

#define BOOST_ALL_DYN_LINK
#define BOOST_LIB_DIAGNOSTIC

#include <iostream>
#include <boost/program_options.hpp>
#include <boost/application.hpp>

using namespace boost::application;
namespace po = boost::program_options;

class my_application_functor_class
{
public:

   int setup(application_ctrl& ctrl)
   {
      if(ctrl.run_type() == application_common)
      {
          std::cout << "Do some setup for common appiaction!" << std::endl;
      }
      else if(ctrl.run_type() == application_server)
      {
          std::cout << "Do some setup for server appiaction!" << std::endl;
      }
	  
      return 0;
   }

   int operator()(const std::vector< std::string >& args, 
                  application_ctrl& ctrl)
   {
      // your application logic here!
      // use ctrl to get state of your application...

      std::cout << "your application logic!" << std::endl;
      ctrl.wait_for_termination_request();

      return 0;
   }
};

int main(int argc, char** argv)
{
   po::variables_map vm;
   po::options_description desc;

   desc.add_options()
      (",f", "run on foreground")
      ;

   po::store(po::parse_command_line(argc, argv, desc), vm);

   // we will run like a daemon or like a common application (foreground)
   if (vm.count("-f")) 
   {
      return common_app<my_application_functor_class>( args(argc, argv) )();
   }
   else
   {  
      return server_app<my_application_functor_class>( args(argc, argv) )();
   }
}

