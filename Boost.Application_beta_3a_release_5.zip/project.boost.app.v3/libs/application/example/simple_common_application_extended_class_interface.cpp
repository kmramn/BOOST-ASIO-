// Copyright 2011-2012 Renato Tegon Forti
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt
// or copy at http://www.boost.org/LICENSE_1_0.txt)

// -----------------------------------------------------------------------------
// This example shows how to create a simplest common application.
// -----------------------------------------------------------------------------

#define BOOST_ALL_DYN_LINK
#define BOOST_LIB_DIAGNOSTIC

#include <boost/uuid/string_generator.hpp>
#include <boost/application.hpp>

using namespace boost::application;

class my_application_functor_class
{
   
public:
   int operator()(const std::vector< application_ctrl::string_type >& args, 
      boost::application::application_ctrl& ctrl)
   {
      // my app logic here
      std::cout << "operator" << std::endl;

      ctrl.wait_for_termination_request();
      return 0;
   }
};

int main(int argc, char* argv[])
{
   return application< my_application< my_application_functor_class > >( args(argc, argv) )();
}

