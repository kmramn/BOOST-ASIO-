// -----------------------------------------------------------------------------
// common_tutorial_1.cpp :  examples that show how use 
// Boost.Application to make a simplest interactive (terminal) application
// -----------------------------------------------------------------------------

// Copyright 2011-2013 Renato Tegon Forti
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying 
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// Boost.Application Server Tutorial 1 - Simplest Server Application
// 

// -----------------------------------------------------------------------------

#define BOOST_ALL_DYN_LINK
#define BOOST_LIB_DIAGNOSTIC

#include <iostream>
#include <fstream>

#include <boost/thread/thread.hpp>
#include <boost/program_options.hpp>
#include <boost/application.hpp>

using namespace boost::application;
namespace po = boost::program_options;

class myapp
{
public:

   int setup(boost::application::application_ctrl& ctrl)
   {
   // provide setup for windows service   
#if defined(BOOST_WINDOWS_API)      

      // get our executable path name
      boost::filesystem::path executable_path_name = ctrl.executable_path_name();

      // define our simple installation schema options
      po::options_description install("service options");
      install.add_options()
         ("help", "produce a help message")
         (",i", "install service")
         (",u", "unistall service")
         ("name", po::value<std::string>()->default_value(ctrl.executable_name().stem().string()), "service name")
         ("display", po::value<std::string>()->default_value(""), "service display name (optional, installation only)")
         ("description", po::value<std::string>()->default_value(""), "service description (optional, installation only)")
         ;

         po::variables_map vm;
         po::store(po::parse_command_line(ctrl.argc(), ctrl.argv(), install), vm);
         boost::system::error_code ec;

         if (vm.count("help")) 
         {
             std::cout << install << std::cout;
             return 1;
         }

         if (vm.count("-i")) 
         {
             install_windows_service(
               setup_arg(vm["name"].as<std::string>()), 
               setup_arg(vm["display"].as<std::string>()), 
               setup_arg(vm["description"].as<std::string>()), 
               setup_arg(executable_path_name)).install(ec);

             std::cout << ec.message() << std::endl;

             return 1;
         }

         if (vm.count("-u")) 
         {
            uninstall_windows_service(
               setup_arg(vm["name"].as<std::string>()), 
               setup_arg(executable_path_name)).uninstall(ec);
			   
            std::cout << ec.message() << std::endl;

            return 1;
         }
#endif

      // return 1 to exit, 0 to continue
      return 0;
   }

   void work_thread(boost::application::application_ctrl* ctrl)
   {
      // your application logic here!

      while(1) 
      {
         boost::this_thread::sleep(boost::posix_time::seconds(1));

          my_log_file_ << "work_thread [" << ctrl->elapsed_time() << 
             "s]" << std::endl;

      } 

   }

   int pause()
   {
      my_log_file_ << "Pause my application..." << std::endl;

      return 1;
   }
   
   int resume()
   {
      my_log_file_ << "Resume my application..." << std::endl;

      return 1;
   }

   int operator()(const std::vector< std::string >& args, 
      boost::application::application_ctrl& ctrl)
   {
      // your application logic here!
      // use ctrl to control your application...

      std::string logfile = ctrl.executable_path().string() + "/log.txt";
      
      my_log_file_.open(logfile.c_str());
      my_log_file_ << "Start Log..." << std::endl;

      // launch a work thread
      boost::thread thread(boost::bind(&myapp::work_thread, this, &ctrl));

      ctrl.wait_for_termination_request();

      return 0;
   }

   // CTRL-C signal handler. 
   // Must return 1, in other case the app state don't will be 
   // changed to "application_stoped"
   int stop()
   {
      my_log_file_ << "Stoping my application..." << std::endl;
      my_log_file_.close();

      return 1;
   }

private:

   std::ofstream my_log_file_;

}; // myapp 

int main(int argc, char *argv[])
{
   return application< 
      application_type<server_application>, // <-- now we are a server
      accept_stop<yes>,                     // Accept stop (If True Windows and UNIX handle this!)
      accept_pause_and_resume<yes>,         // Accept pause and resume (Windows Only, ignored on UNIX)
      my_application< myapp > >( args(argc, argv))();
}

