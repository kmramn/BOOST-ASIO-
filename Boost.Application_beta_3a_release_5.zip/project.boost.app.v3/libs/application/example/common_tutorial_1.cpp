// -----------------------------------------------------------------------------
// common_tutorial_1.cpp :  examples that show how use 
// Boost.Application to make a simplest interactive (terminal) application
// -----------------------------------------------------------------------------

// Copyright 2011-2013 Renato Tegon Forti
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying 
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// Boost.Application Common Tutorial 1 - Simplest Application (Terminal)
// 

// -----------------------------------------------------------------------------

#include <iostream>

#define BOOST_ALL_DYN_LINK
#define BOOST_LIB_DIAGNOSTIC

#include <boost/thread/thread.hpp>
#include <boost/application.hpp>

using namespace boost::application;


class myapp
{
public:

   int operator()(const std::vector< application_ctrl::string_type >& args, 
                 application_ctrl& ctrl)
   {
      // your application logic here!
      // use ctrl to get state of your application...

      do 
      {
         boost::this_thread::sleep(boost::posix_time::seconds(1));

         std::cout << "In main, elapsed time: " << 
            ctrl.elapsed_time() << "s" << std::endl;

      } while (ctrl.state() == application_running);

      return 0;
   }

}; // myapp 

int main(int argc, char *argv[])
{
   return application< my_application< myapp > >( args(argc, argv))();
}

