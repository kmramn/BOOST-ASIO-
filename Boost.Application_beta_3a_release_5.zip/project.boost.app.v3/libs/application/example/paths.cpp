// Copyright 2011-2012 Renato Tegon Forti
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt
// or copy at http://www.boost.org/LICENSE_1_0.txt)

// -----------------------------------------------------------------------------
// This example shows how paths of executable module.
// -----------------------------------------------------------------------------

#define BOOST_ALL_DYN_LINK
#define BOOST_LIB_DIAGNOSTIC

#include <boost/application.hpp>

using namespace boost::application;

class my_application_functor_class
{
   
public:
   int operator()(const std::vector< application_ctrl::string_type >& args, 
      boost::application::application_ctrl& ctrl)
   {
      // my app logic here

      std::cout 
         << std::endl
         << "---------- ---------- ----------"
         << "---------- ---------- ----------" 
         << std::endl;
	  
      std::cout 
         << "application working directory: " 
         << std::endl
         << ctrl.current_path() 
         << std::endl
         << "---------- ---------- ----------"
         << std::endl;

      std::cout 
         << "application executable file name (excluding extension): " 
         << std::endl
         << ctrl.executable_name() 
         << std::endl
         << "---------- ---------- ----------"
         << std::endl;
	  
      std::cout 
         << "application executable full file name (including extension): " 
         << std::endl
         << ctrl.executable_full_name() 
         << std::endl
         << "---------- ---------- ----------"
         << std::endl;

      std::cout 
         << "absolute path of application executable: " 
         << std::endl
         << ctrl.executable_path() 
         << std::endl
         << "---------- ---------- ----------"
         << std::endl;

      std::cout 
         << "application executable full file name (including extension): " 
         << std::endl
         << ctrl.executable_path_name() 
         << std::endl
         << "---------- ---------- ----------"
         << std::endl;

      ctrl.wait_for_termination_request();
      return 0;
   }
};

int main(int argc, char* argv[])
{
   return application< my_application< my_application_functor_class > >( args(argc, argv) )();
}

