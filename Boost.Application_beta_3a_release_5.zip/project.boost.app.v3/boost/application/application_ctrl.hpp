// application_impl.hpp  ----------------------------------------------------//
// -----------------------------------------------------------------------------

// Copyright 2011-2012 Renato Tegon Forti

// Distributed under the Boost Software License, Version 1.0.
// See http://www.boost.org/LICENSE_1_0.txt

// -----------------------------------------------------------------------------

// Revision History
// 06-01-2012 dd-mm-yyyy - Initial Release
// 11-04-2012 dd-mm-yyyy - Added environment variable manipulation support
// 10-09-2013 dd-mm-yyyy - The single instance now is identified by a uuid

// -----------------------------------------------------------------------------

#ifndef BOOST_APPLICATION_APPLICATION_CTRL_HPP
#define BOOST_APPLICATION_APPLICATION_CTRL_HPP

// std
#include <map>
#include <time.h>
#include <stdlib.h>
// boost
#include <boost/function.hpp>
#include <boost/noncopyable.hpp>
#include <boost/filesystem/path.hpp>
#include <boost/filesystem/operations.hpp> 
#include <boost/thread.hpp>
#include <boost/algorithm/string.hpp>
// application
#include <boost/application/config.hpp>
#include <boost/application/application_types.hpp>

#ifdef BOOST_MSVC
#  pragma warning(push)
#  pragma warning(disable : 4251 4231 4275 4660)
#endif

// handle OS specific environ functions
#if defined(BOOST_POSIX_API)
#   define BOOST_APPLICATION_PUTENV ::putenv 
#   define BOOST_APPLICATION_GETENV ::getenv 
#   define BOOST_APPLICATION_ENVVAR ::environ
#elif defined(BOOST_WINDOWS_API)
// _tgetenv 
// _tputenv 
#   if defined(BOOST_APPLICATION_STD_WSTRING)
#      define BOOST_APPLICATION_ENVVAR ::_wenviron 
#      define BOOST_APPLICATION_GETENV ::_wgetenv 
#      define BOOST_APPLICATION_PUTENV ::_wputenv 
#   else
#      define BOOST_APPLICATION_ENVVAR ::_environ
#      define BOOST_APPLICATION_GETENV ::getenv 
#      define BOOST_APPLICATION_PUTENV ::_putenv 
#   endif
#endif

namespace boost { namespace application {

   // used only in single isntance handler
   using uuids::uuid;
   
   // application current state
   enum application_state
   {
      application_stoped = 0,
      application_running,
      application_paused
   };

   // application
   enum application_run_type
   {
      application_common = 0,
      application_server
   };
	
   // application control interface

   // value_type is the character type used by the operating system API to
   // represent string or wstring.
   template <typename value_type>
   class application_ctrl_ : noncopyable
   {
   public:

      // my ctrl string types to be used internaly in more easy way
      // some as character_types::char_type, and so on..
      typedef value_type char_type;
      typedef std::basic_string<char_type> string_type;
      typedef uuid instance_id;

      // callback methods   
      typedef boost::function< int (void) > ctrl_mtd;
      typedef boost::function< bool (application_ctrl_&) > insc_mtd; 
      typedef boost::function< int (application_ctrl_&) > stup_mtd;
      typedef boost::function< instance_id (void) > inst_mtd;
      typedef boost::function< int 
         (const std::vector< string_type >& args, application_ctrl_& ) > main_mtd;

      template <typename T>
      application_ctrl_(const arg_type<T> &args, 
                        const main_mtd& main, 
                        const insc_mtd& single_instance,
                        const inst_mtd& limit_single_instance,
                        const ctrl_mtd& accept_pause,
                        const ctrl_mtd& pause, 
                        const ctrl_mtd& resume, 
                        const ctrl_mtd& accept_stop,
                        const ctrl_mtd& stop,
                        const stup_mtd& setup)
         : state_(application_running)
      {

         // set start time of application, this is 
         // needed to determine elapsed time
         time(&begin_time_);

         // our args in vector mode
         argv_ = args.get();

         // hold user application command eg:
         // /bin/myapp.exe
         command_ = argv_[0];

         // my main method
         main_ = main;

         // ctrl handlers methods
         single_instance_ = single_instance;
         limit_single_instance_ = limit_single_instance;

         accept_pause_ = accept_pause;
         pause_ = pause;
         resume_ = resume; 

         accept_stop_ = accept_stop;
         stop_ = stop;
	  
         // setup application
         setup_ = setup;
      }

      virtual ~application_ctrl_()
      {
      }
	  
	   // run application code
      virtual int run(void) = 0;

      //
      // Util
      //

      // get return code from main
      int result_code(void) const
      {
         return result_code_;
      }

      virtual application_run_type run_type() = 0;

      // returns current process id (PID)
      unsigned int process_id() const
      {
         return process_id_;
      }

      // returns state of application that can be:
      // application_stoped, application_running, application_paused
      application_state state() const
      {
         return state_;
      }

      // returns the application elapsed time in seconds.
      double elapsed_time() const
      {
         boost::lock_guard<boost::mutex> lock(mutex_);

         time_t now; 
         time(&now);

         return difftime(now, begin_time_);
      }

      // path and app names handle session

      // returns the application working path
      filesystem::path current_path(void)
      {
         boost::lock_guard<boost::mutex> lock(mutex_);

         return filesystem::current_path();
      }

      // returns the application executable file name (excluding extension) 
      filesystem::path executable_name(void)
      {
         boost::lock_guard<boost::mutex> lock(mutex_);

         filesystem::path module_path(executable_path_name());
         return module_path.stem();
      }
    
      // returns the application executable full file name (including extension) 
      filesystem::path executable_full_name(void)
      {
         boost::lock_guard<boost::mutex> lock(mutex_);

         filesystem::path module_path(executable_path_name());
         return module_path.filename();
      }
  
      // returns the absolute path of application executable
      filesystem::path executable_path(void)
      {
         boost::lock_guard<boost::mutex> lock(mutex_);

         filesystem::path module_path(executable_path_name());
         return module_path.parent_path();
      }

      // Returns the application executable full file name (including extension) 
      const filesystem::path& executable_path_name(void) const
      {
         return module_path_name_;
      }

      // environ variable handle session

      // check if given environ variable exist. 
      template <typename T>
      bool has_environ_var(const environ_var_type<T>& environ_var_name) const
      {
         char_type* environ = NULL;
         environ = BOOST_APPLICATION_GETENV(environ_var_name.get().c_str());

         if(environ == NULL)
            return false;
  
         return true;
      }

      // change a existent (overwrite = true), or add new environ variable
      // on sucess returns false
      template <typename T>
      bool set_environ_var(const environ_var_type<T>& environ_var_name, 
         const environ_var_type<T>& environ_var_value, bool overwrite = true)
      {  
         boost::lock_guard<boost::mutex> lock(mutex_);

         // note: we dont have setenv on windows
         if((has_environ_var(environ_var_name) == true) && (overwrite == false))
         {
            return true;
         }

         string_type separator;
#if defined(BOOST_APPLICATION_STD_WSTRING)
         separator = L"=";
#else
         separator = "=";
#endif 
         string_type envvar = 
            environ_var_name.get() + separator + environ_var_value.get();

         // The putenv() function returns zero on success, or -1 if an error occurs.  
         if(BOOST_APPLICATION_PUTENV((char_type*)envvar.c_str()) == 0)
             return false;

         return true;
      }

      // remove a given environ variable from environment.
      // on sucess returns false
      // if var don't exist, return false
      template <typename T>
      bool unset_environ_var(const environ_var_type<T>& environ_var_name)
      {
         boost::lock_guard<boost::mutex> lock(mutex_);

         // var don't exist, return false
         if(has_environ_var(environ_var_name) == false)
         {
            return false;
         }

         string_type separator;
#if defined(BOOST_APPLICATION_STD_WSTRING)
         separator = L"=";
#else
         separator = "=";
#endif

         string_type unset = environ_var_name.get() + separator;

         if(BOOST_APPLICATION_PUTENV((char_type*)unset.c_str()) == 0)
            return false;

         return true;
      }

      // returns the variable environ that points to an array of 
      // strings called the `environment' formated in a map (key,value)
      // of strings
      std::map< string_type, string_type > environ_var_map(void)
      {
         boost::lock_guard<boost::mutex> lock(mutex_);

         std::map< string_type, string_type > environ_map;

         char_type **env;
         for (env = BOOST_APPLICATION_ENVVAR; *env != NULL; env++) 
         {
            bool flag = false;

            string_type key, value;
            string_type str(*env);

            std::vector<string_type> tokens;
            boost::split(tokens, str, boost::is_any_of("="));

            for(int i = 0; i < tokens.size(); i++)
            {
               if(flag == false)
               {
                  key = tokens[i]; flag = true;
               }
               else
               {
                  value = tokens[i];
               }
            }

            environ_map[key] = value;

         }

         return environ_map;
      }

      // get value of given environ variable, if given is not defined
      // empty string are returned.
      // use has_environ to check existence of it.
      template <typename T>
      string_type environ_var(const environ_var_type<T>& environ_var_name)
      {
         boost::lock_guard<boost::mutex> lock(mutex_);

         // var don't exist, return false
         if(has_environ_var(environ_var_name) == false)
         {
            return string_type();
         }

         // The getenv() function returns a pointer to the value in 
         // the environment, or NULL if there is no match.  
         return string_type(BOOST_APPLICATION_GETENV(environ_var_name.get().c_str())); 
      }

      // application args (argv) handle session

      // Get argc
      int argc() const
      {
         return argv_.size();
      }

      // Get argv
      value_type** argv() 
      {
         return &argv_[0];
      }

      // Wait for termination signal, for sample CTRL-C
      // or Windows Service Stop or other stop signal
      virtual void wait_for_termination_request(void) = 0;

   protected:

      //
      // Our methods, we call it based on behaviour defined by application
      // type used be user on instantiation.
      //

      // main method
      //

      main_mtd main_;

      // ctrl handles
      //

      insc_mtd single_instance_;
      inst_mtd limit_single_instance_;

      // Windows specific
      ctrl_mtd accept_pause_;
      ctrl_mtd pause_;
      ctrl_mtd resume_; 

      ctrl_mtd accept_stop_;
      ctrl_mtd stop_;
	  
      // Called to applicatio setup
      stup_mtd setup_;

      // app states
      //

      int result_code_;
      unsigned int process_id_;

      application_state state_;

      filesystem::path module_path_name_;

      std::vector<char_type*> argv_;
      string_type command_;

      // Needed to determine elapsed time
      time_t begin_time_;

      boost::mutex mutex_;  

   };

   /////////////////////////////////////////////////////////////////////////////
   // application_ctrl
   //

   // application_ctrl versions for common string and wide string
   typedef application_ctrl_<character_types::char_type> application_ctrl;
   // wchar_t / char

}} // boost::application 

#ifdef BOOST_MSVC
#pragma warning(pop)
#endif

#endif // BOOST_APPLICATION_APPLICATION_CTRL_HPP
 