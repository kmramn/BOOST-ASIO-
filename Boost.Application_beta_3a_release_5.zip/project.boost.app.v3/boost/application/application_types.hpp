// shared_library.hpp -------------------------------------------------------//
// -----------------------------------------------------------------------------

// Copyright 2011-2012 Renato Tegon Forti

// Distributed under the Boost Software License, Version 1.0.
// See http://www.boost.org/LICENSE_1_0.txt

// -----------------------------------------------------------------------------

// Revision History
// 05-04-2013 dd-mm-yyyy - Initial Release

// -----------------------------------------------------------------------------

#ifndef BOOST_APPLICATION_APPLICATION_TYPES_HPP
#define BOOST_APPLICATION_APPLICATION_TYPES_HPP

#include <boost/application/config.hpp>
#include <boost/application/base_type.hpp>

namespace boost { namespace application {

   template <typename Agrs>
   class arg_type 
      : public base_type<Agrs>
   {
   public:
      explicit arg_type(const Agrs &args)
         : base_type<Agrs>(args) {}
   };

   template <typename String>
   class environ_var_type  
      : public base_type<String>
   {
   public:
      explicit environ_var_type(const String &s)
         : base_type<String>(s) {}
   };

   template <typename String>
   class setup_type  
      : public base_type<String>
   {
   public:
      explicit setup_type(const String &s)
         : base_type<String>(s) {}
   };

}} // boost::application

#endif // BOOST_APPLICATION_SHARED_LIBRARY_TYPES_HPP

