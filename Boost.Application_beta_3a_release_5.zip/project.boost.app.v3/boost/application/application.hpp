// application.hpp  ---------------------------------------------------------//
// -----------------------------------------------------------------------------

// Copyright 2011-2013 Renato Tegon Forti

// Distributed under the Boost Software License, Version 1.0.
// See http://www.boost.org/LICENSE_1_0.txt

// -----------------------------------------------------------------------------

// Revision History
// 01-02-2012 dd-mm-yyyy - Initial Release
// 01-09-2013 dd-mm-yyyy - New Version

// -----------------------------------------------------------------------------

#ifndef BOOST_APPLICATION_APPLICATION_HPP
#define BOOST_APPLICATION_APPLICATION_HPP

// std
#include <iostream>
#include <vector>
// boost
#include <boost/function.hpp>
#include <boost/bind.hpp>
#include <boost/noncopyable.hpp>
#include <boost/utility/enable_if.hpp>
#include <boost/uuid/uuid.hpp>
#include <boost/parameter.hpp>
#include <boost/type_traits.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/uuid/uuid_io.hpp>
// appication
#include <boost/application/config.hpp>
#include <boost/application/sefina.hpp>
#include <boost/application/parameter.hpp>
#include <boost/application/application_initializers.hpp>
// applicatio types
#include <boost/application/common_application.hpp>
#include <boost/application/server_application.hpp>

namespace boost { namespace application {

   using uuids::uuid;

   // This is main application class
   // 
   // Provides a means to run your application like a:
   // 
   //  * Command-line Application;
   //  * Windows Service Application;
   //  * Unix/Linux Daemon Application.
   // 
   // The class provide handles for start/stop, pause/resume
   // limit application to single instance running,
   // eviroment variable handle and many others features.
   // Check documentation for know more!
   // 
   //
   // The simplest use is as:
   // 
   // TODO: UPDATE HERE!
   //
   // class my_application_functor_class
   // {
   //    int operator()(const std::vector< std::string / std::wstring  >& args, 
   //       boost::application::application_ctrl& ctrl)
   //    {
   //       // my app logic
   //       return 0;
   //    }
   // };
   //
   // Instantiate Command-line Application
   // 
   // int main() {
   //   return application< 
   //     my_application<my_application_functor_class> >(  args(argc, argv), ec  )();
   // }
   // 
   // Instantiate Service/Daemon Application;
   // 
   // int main() {
   //    return application< 
   //       application_type<server_application>,
   //       accept_stop<yes>, accept_pause_and_resume<yes>,
   //       my_application<my_application_functor_class> >( args(argc, argv) )();
   // }
   //
   template <
      class T0
         , class T1 = parameter::void_
         , class T2 = parameter::void_
         , class T3 = parameter::void_
   >
   class  application : public noncopyable 
   {
   public:

      // Create ArgumentPack
      typedef typename
         class_signature::bind<T0, T1, T2, T3>::type args;

      // -----------------------------------------------------------------------

      // Extract logical parameters.
      typedef typename parameter::value_type<
         args, tag::my_application
      >::type my_application_;

      typedef typename parameter::value_type<
         args, tag::application_type, common_application 
      >::type application_type_;

      typedef typename parameter::value_type<
         args, tag::accept_stop, yes
      >::type accept_stop_;

      typedef typename parameter::value_type<
         args, tag::accept_pause_and_resume, no
      >::type accept_pause_and_resume_;


      // -----------------------------------------------------------------------

      // constructors, etc.

      // throw boost::system::system_error on failure.
      template <typename T>
      application(const arg_type<T> &arg)
         : mechanism_(arg)
      {
      }

      // set ec to indicate what error occurred, if any.
      template <typename T>
      application(const arg_type<T> &arg, boost::system::error_code &ec)
         : mechanism_(arg, ec)
      {
      }

      virtual ~application()
      {
      }

      // public interface

      // run application user logic, by calling run.
      int run()
      {
         return mechanism_.run();
      }

      // run application user logic, using functor.
      int operator()()
      {
         return mechanism_.run();
      }

      // get status of execution of application.
      int status()
      {
         return mechanism_.status();
      }

   protected:

      // mechanism is used to pack all aplication handles methods, and enable it when
      // requisited by user on my_application class.
      class mechanism : public my_application_
      {
      public:

         template <typename T>
         mechanism(const arg_type<T> &args)
         {
            engine_ = new application_type_(
               // required
               args, 
               boost::bind<int>  ( &my_application_::operator(),          this, _1, _2),
               // handlers, may or may not be enabled be the user on my_application class
               boost::bind<bool> ( &mechanism::single_instance,           this, _1    ),
               boost::bind<uuid> ( &mechanism::limit_single_instance,     this        ),
               boost::bind<bool> ( &mechanism::accept_pause_and_resume,   this        ),
               boost::bind<int>  ( &mechanism::pause,                     this        ),
               boost::bind<int>  ( &mechanism::resume,                    this        ),
               boost::bind<bool> ( &mechanism::accept_stop,               this        ),
               boost::bind<int>  ( &mechanism::stop,                      this        ),
               boost::bind<int>  ( &mechanism::setup,                     this, _1    )
            );
         }

         template <typename T>
         mechanism(const arg_type<T> &args, boost::system::error_code &ec)
         {
            engine_ = new application_type_(
               // required
               args, 
               boost::bind<int>  ( &my_application_::operator(),          this, _1, _2),
               // handlers, may or may not be enabled be the user on my_application class
               boost::bind<bool> ( &mechanism::single_instance,           this, _1    ),
               boost::bind<uuid> ( &mechanism::limit_single_instance,     this        ),
               boost::bind<bool> ( &mechanism::accept_pause_and_resume,   this        ),
               boost::bind<int>  ( &mechanism::pause,                     this        ),
               boost::bind<int>  ( &mechanism::resume,                    this        ),
               boost::bind<bool> ( &mechanism::accept_stop,               this        ),
               boost::bind<int>  ( &mechanism::stop,                      this        ),
               boost::bind<int>  ( &mechanism::setup,                     this, _1    ),
               ec
            );
         }

         virtual ~mechanism()
         {
            delete engine_;
         }

         // public interface

         int run()
         {
            return engine_->run();
         }

         int result_code()
         {
            return engine_->result_code();
         }

         //
         // Application CTRL Handlers
         // Can be defined by user in functor class
         //

         bool accept_pause_and_resume()
         {
            return boost::is_same<accept_pause_and_resume_, yes>::value;
         }

         int pause()
         {
            return pause_handler<my_application_>(this);
         }

         int resume()
         {
            return resume_handler<my_application_>(this);
         }

         bool accept_stop()
         {
            return boost::is_same<accept_stop_, yes>::value;
         }

         int stop()
         {
            return stop_handler<my_application_>(this);
         }

         int setup(application_ctrl& ctrl)
         {
            return setup_handler<my_application_>(this, ctrl);
         }
   
         uuid limit_single_instance(void)
         {
            return limit_single_instance_handler<my_application_>(this);
         }
        
         bool single_instance(application_ctrl& ctrl)
         {
            return single_instance_handler<my_application_>(this, ctrl);
         }

      protected:

         // --------------------------------------------------------------------
         // Auto enabled handlers
         // --------------------------------------------------------------------

         // stop
         // --------------------------------------------------------------------
         CTRL_HANDLER_MEM_FUNC_EXIST(stop, has_stop); 

         template<typename T>  
         typename boost::enable_if_c<has_stop<T, 
            int(T::*)()>::value, int>::type 
            stop_handler(T * t) 
         { 
            return t->stop(); 
         } 

         template<typename T>  
         typename boost::enable_if_c<!has_stop<T, 
            int(T::*)()>::value, int>::type 
            stop_handler(T * t) 
         {
            return 1; 
         } 

         // setup
         // --------------------------------------------------------------------
         CTRL_HANDLER_MEM_FUNC_EXIST(setup, has_setup); 

         template<typename T>  
         typename boost::enable_if_c<has_setup<T, 
            int(T::*)(application_ctrl& ctrl)>::value, int>::type 
            setup_handler(T * t, application_ctrl& ctrl) 
         { 
            return t->setup(ctrl); 
         } 

         template<typename T>  
         typename boost::enable_if_c<!has_setup<T, 
            int(T::*)(application_ctrl& ctrl)>::value, int>::type 
            setup_handler(T * t, application_ctrl& ctrl) 
         {
            return 0; 
         }

         // pause (windows only)
         // --------------------------------------------------------------------
         CTRL_HANDLER_MEM_FUNC_EXIST(pause, has_pause); 

         template<typename T>  
         typename boost::enable_if_c<has_pause<T, 
            int(T::*)()>::value, int>::type 
            pause_handler(T * t) 
         { 
            return t->pause(); 
         } 

         template<typename T>  
         typename boost::enable_if_c<!has_pause<T, 
            int(T::*)()>::value, int>::type 
            pause_handler(T * t) 
         {
            return 0; 
         } 

         // resume (windows only)
         // --------------------------------------------------------------------
         CTRL_HANDLER_MEM_FUNC_EXIST(resume, has_resume); 

         template<typename T>  
         typename boost::enable_if_c<has_resume<T, 
            int(T::*)()>::value, int>::type 
            resume_handler(T * t) 
         { 
            return t->resume(); 
         } 

         template<typename T>  
         typename boost::enable_if_c<!has_resume<T, 
            int(T::*)()>::value, int>::type 
            resume_handler(T * t) 
         {
            return 1; 
         } 
        
         // limit_single_instance app 
         // --------------------------------------------------------------------
         CTRL_HANDLER_MEM_FUNC_EXIST(limit_single_instance, 
            has_limit_single_instance); 

         template<typename T>  
         typename boost::enable_if_c<has_limit_single_instance<T, 
            uuid(T::*)()>::value, uuid>::type 
            limit_single_instance_handler(T * t) 
         { 
            return t->limit_single_instance(); 
         } 

         template<typename T>  
         typename boost::enable_if_c<!has_limit_single_instance<T, 
            uuid(T::*)()>::value, uuid>::type 
            limit_single_instance_handler(T * t) 
         {
            return uuids::uuid(); 
         } 

         // single_instance
         // --------------------------------------------------------------------
         CTRL_HANDLER_MEM_FUNC_EXIST(single_instance, has_single_instance); 

         template<typename T>  
         typename boost::enable_if_c<has_single_instance<T, 
            bool(T::*)(application_ctrl& ctrl)>::value, 
            bool>::type 
            single_instance_handler(T * t, application_ctrl& ctrl) 
         { 
            return t->single_instance(ctrl); 
         } 

         template<typename T>  
         typename boost::enable_if_c<!has_single_instance<T, 
            bool(T::*)(application_ctrl& ctrl)>::value, 
            bool>::type 
            single_instance_handler(T * t, application_ctrl& ctrl) 
         {
            return true; 
         } 

      private:
         
         // our application type engine taht can be:
         // common (command line applicatiom)or server 
         // (windows service, unix daemon) type application
         application_type_ *engine_;

      }; // mechanism

   private:

      // our application mechanism, this hold an engine, that hold
      // a application type (common/server), see: application_type_
      mechanism  mechanism_;

   }; // application

}} // boost::application

#endif // BOOST_APPLICATION_APPLICATION_HPP
