//  application_impl.hpp  ---------------------------------------------------//
// -----------------------------------------------------------------------------

//  Copyright 2011-2012 Renato Tegon Forti

//  Distributed under the Boost Software License, Version 1.0.
//  See http://www.boost.org/LICENSE_1_0.txt

// -----------------------------------------------------------------------------

// Revision History
// 06-01-2012 dd-mm-yyyy - Initial Release

// -----------------------------------------------------------------------------

#ifndef BOOST_APPLICATION_LIMIT_SINGLE_INSTANCE_HPP
#define BOOST_APPLICATION_LIMIT_SINGLE_INSTANCE_HPP

#include <boost/noncopyable.hpp>
#include <boost/application/config.hpp>

namespace boost { namespace application { 

   // value_type is the character type used by the operating system API to
   // represent string or wstring.
   template <typename value_type>
   class limit_single_instance_ : noncopyable
   {
   public:
   
      typedef value_type char_type;
      typedef std::basic_string<char_type> string_type;
	  
      virtual bool lock(const string_type& instance_id, boost::system::error_code &ec) = 0;
      virtual bool is_another_instance_running() = 0;
      virtual void release(void) = 0;

   };
   
   typedef limit_single_instance_<character_types::char_type> limit_single_instance;

} }  // boost::application

#endif // BOOST_APPLICATION_IMPL_LIMIT_SINGLE_INSTANCE_HPP
		