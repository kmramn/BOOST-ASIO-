// shared_library.hpp -------------------------------------------------------//
// -----------------------------------------------------------------------------

// Copyright 2011-2012 Renato Tegon Forti

// Distributed under the Boost Software License, Version 1.0.
// See http://www.boost.org/LICENSE_1_0.txt

// -----------------------------------------------------------------------------

// Revision History
// 05-04-2013 dd-mm-yyyy - Initial Release

// -----------------------------------------------------------------------------

#ifndef BOOST_APPLICATION_APPLICATION_INITIALIZERS_HPP
#define BOOST_APPLICATION_APPLICATION_INITIALIZERS_HPP

#include <boost/application/config.hpp>
#include <boost/application/application_types.hpp>

#include <boost/filesystem/path.hpp>

namespace boost { namespace application {

   // arg_type session
   inline arg_type< std::vector< character_types::char_type*> > 
      args(int argc,  character_types::char_type **argv)
   {
      // we will pack args on vector
      std::vector<character_types::char_type*> arguments;
      for(int i=0; i <argc; i++)
      {
         arguments.push_back(argv[i]);
      }

      return arg_type< std::vector<character_types::char_type*> >(arguments);
   }

   // environ_variable session
   inline environ_var_type<character_types::string_type> 
      environ_variable(const character_types::char_type *s)
   {
      return environ_var_type<character_types::string_type>(s);
   }

   inline environ_var_type<character_types::string_type> 
      environ_variable(const character_types::string_type &s)
   {
      return environ_var_type<character_types::string_type>(s);
   }

   // setup session
   inline setup_type<character_types::string_type> 
      setup_arg(const character_types::char_type *s)
   {
      return setup_type<character_types::string_type>(s);
   }

   inline setup_type<character_types::string_type> 
      setup_arg(const character_types::string_type &s)
   {
      return setup_type<character_types::string_type>(s);
   }

   inline setup_type<character_types::string_type> 
      setup_arg(const boost::filesystem::path &p)
   {
#if defined(BOOST_APPLICATION_STD_WSTRING)
      return setup_type<character_types::string_type>(p.wstring());
#else
      return setup_type<character_types::string_type>(p.string());
#endif
   }

}} // boost::application

#endif // BOOST_APPLICATION_SHARED_LIBRARY_INITIALIZERS_HPP
