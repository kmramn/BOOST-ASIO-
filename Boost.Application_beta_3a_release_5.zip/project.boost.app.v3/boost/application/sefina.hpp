// application.hpp  ----------------------------------------------------------//

// Copyright 2011-2012 Renato Tegon Forti

// Distributed under the Boost Software License, Version 1.0.
// See http://www.boost.org/LICENSE_1_0.txt

// Revision History
// 04-03-2012 dd-mm-yyyy - Initial Release

#ifndef BOOST_APPLICATION_SEFINA_HPP
#define BOOST_APPLICATION_SEFINA_HPP

   // This macro check if a ctrl handler exists in child class (SEFINA)
   #define CTRL_HANDLER_MEM_FUNC_EXIST(func, name)                            \
   template<typename T, typename R>                                           \
   struct name                                                                \
   {                                                                          \
      typedef char yes[1];                                                    \
      typedef char no [2];                                                    \
                                                                              \
      template <typename U, U>                                                \
      struct type_check;                                                      \
                                                                              \
      template <typename _1> static yes &chk(type_check<R, &_1::func> *);     \
      template <typename   > static no  &chk(...);                            \
                                                                              \
      static bool const value =                                               \
      sizeof(chk<T>(0)) == sizeof(yes);                                       \
   }
   
namespace boost { namespace application {
   
}} // boost::application   

#endif // BOOST_APPLICATION_SEFINA_HPP

