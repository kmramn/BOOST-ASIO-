// application.hpp  ----------------------------------------------------------//

// Copyright 2011-2012 Renato Tegon Forti

// Distributed under the Boost Software License, Version 1.0.
// See http://www.boost.org/LICENSE_1_0.txt

// Revision History
// 04-03-2012 dd-mm-yyyy - Initial Release

#ifndef BOOST_APPLICATION_PARAMETER_HPP
#define BOOST_APPLICATION_PARAMETER_HPP

namespace boost { namespace application {

   // define keywords for each template parameter of class application
   // my_application : user application class
   // application_type : application type engine class
   // accept_stop : my_application will provide stop handler
   // accept_pause_and_resume : my_application will provide pause/resume handler

   BOOST_PARAMETER_TEMPLATE_KEYWORD(my_application)
   BOOST_PARAMETER_TEMPLATE_KEYWORD(application_type)
   BOOST_PARAMETER_TEMPLATE_KEYWORD(accept_stop)
   BOOST_PARAMETER_TEMPLATE_KEYWORD(accept_pause_and_resume)

   // our ParameterSpec, 
   typedef parameter::parameters<
      parameter::required<tag::my_application, boost::is_class<boost::mpl::_> >
      , parameter::optional<tag::application_type >
      , parameter::optional<tag::accept_stop>
      , parameter::optional<tag::accept_pause_and_resume>
   > class_signature;

   // our handler_activated flags to use in our class application
   struct yes{};
   struct no{};
   
}} // boost::application   

#endif // BOOST_APPLICATION_PARAMETER_HPP

