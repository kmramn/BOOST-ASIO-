// application_impl.hpp  ----------------------------------------------------//
// -----------------------------------------------------------------------------

// Copyright 2011-2013 Renato Tegon Forti

// Distributed under the Boost Software License, Version 1.0.
// See http://www.boost.org/LICENSE_1_0.txt

// -----------------------------------------------------------------------------

// Revision History
// 30-01-2012 dd-mm-yyyy - Initial Release

// -----------------------------------------------------------------------------

#ifndef BOOST_APPLICATION_COMMON_APPLICATION_HPP
#define BOOST_APPLICATION_COMMON_APPLICATION_HPP

#include <boost/noncopyable.hpp>
#include <boost/function.hpp>

#include <boost/application/config.hpp>
#include <boost/application/application_types.hpp>
#if defined( BOOST_WINDOWS_API )
#include <boost/application/impl/windows/common_application_impl.hpp>
#elif defined( BOOST_POSIX_API )
#include <boost/application/impl/posix/common_application_impl.hpp>
#else
#error "Sorry, no boost application are available for this platform."
#endif

#ifdef BOOST_MSVC
#  pragma warning(push)
#  pragma warning(disable : 4251 4231 4275 4660)
#endif

namespace boost { namespace application {

   // Common interface for common application, see common_application_impl 
   // for OS specific implementation details.
   class  common_application : noncopyable 
   {
   public:
    
      // constructors, etc.

      // throw version
      template <typename T>
      common_application(const arg_type<T> &args, 
                         const application_ctrl::main_mtd& main, 
                         const application_ctrl::insc_mtd& single_instance,
                         const application_ctrl::inst_mtd& limit_single_instance,
                         const application_ctrl::ctrl_mtd& accept_pause,
                         const application_ctrl::ctrl_mtd& pause, 
                         const application_ctrl::ctrl_mtd& resume, 
                         const application_ctrl::ctrl_mtd& accept_stop,
                         const application_ctrl::ctrl_mtd& stop,
                         const application_ctrl::stup_mtd& setup)
         : impl_(new common_application_impl(args, main, single_instance, limit_single_instance, accept_pause, pause, resume, accept_stop, stop, setup))
      {
      }

      // ec version.
      template <typename T>
      common_application(const arg_type<T> &args, 
                         const application_ctrl::main_mtd& main, 
                         const application_ctrl::insc_mtd& single_instance,
                         const application_ctrl::inst_mtd& limit_single_instance,
                         const application_ctrl::ctrl_mtd& accept_pause,
                         const application_ctrl::ctrl_mtd& pause, 
                         const application_ctrl::ctrl_mtd& resume, 
                         const application_ctrl::ctrl_mtd& accept_stop,
                         const application_ctrl::ctrl_mtd& stop,
                         const application_ctrl::stup_mtd& setup, 
                         boost::system::error_code &ec)
         : impl_(new common_application_impl(args, main, single_instance, limit_single_instance, accept_pause, pause, resume, accept_stop, stop, setup, ec))
      {
      }

      virtual ~common_application()
      {
         delete impl_;
      }

      // run application user defined logic
      int run(void) 
      {
         return impl_->run();
      }

      // result code that need be exposed to application class,
      // all other ctrl methods are in application_ctrl that is sent to 
      // client, see application_ctrl to full method list
      int result_code(void) const 
      {
         return impl_->result_code();
      }

   private:

      application_ctrl *impl_;
  
   };
	
}} // boost::application 

#ifdef BOOST_MSVC
#pragma warning(pop)
#endif

#endif // BOOST_APPLICATION_COMMON_APPLICATION_HPP
       