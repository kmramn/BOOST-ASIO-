// application.hpp  ---------------------------------------------------------//
// -----------------------------------------------------------------------------

// Copyright 2011-2013 Renato Tegon Forti

// Distributed under the Boost Software License, Version 1.0.
// See http://www.boost.org/LICENSE_1_0.txt

// -----------------------------------------------------------------------------

// Revision History
// 20-09-2013 dd-mm-yyyy - Initial Release

// -----------------------------------------------------------------------------

#ifndef BOOST_APPLICATION_APPLICATION_NATURAL_INTERFACE_HPP
#define BOOST_APPLICATION_APPLICATION_NATURAL_INTERFACE_HPP

// appication
#include <boost/application/config.hpp>
#include <boost/application/application.hpp>

namespace boost { namespace application {

   //
   // easy natual interface
   //

   // e.g. return server_app<yourt_server_functor_class>( boost::application::args(argc, argv) )();
   template<typename Application> struct server_app 
      : public application< application_type<server_application>, accept_stop<yes>, my_application<Application> >
   {
      // throw boost::system::system_error on failure.
      template <typename T>
      server_app(const arg_type<T> &arg)
         : application< application_type<server_application>, accept_stop<yes>, my_application<Application> >(arg)
      {
      }

      // set ec to indicate what error occurred, if any.
      template <typename T>
      server_app(const arg_type<T> &arg, boost::system::error_code &ec)
         : application< application_type<server_application>, accept_stop<yes>, my_application<Application> >(arg, ec) 
      {
      }
   };

   // e.g. return commom_app<yourt_common_functor_class>( boost::application::args(argc, argv) )();
   template<typename Application> struct common_app 
      : public application< application_type<common_application>, accept_stop<yes>, my_application<Application> >
   {
      // throw boost::system::system_error on failure.
      template <typename T>
      common_app(const arg_type<T> &arg)
         : application< application_type<common_application>, accept_stop<yes>, my_application<Application> >(arg)
      {
      }

      // set ec to indicate what error occurred, if any.
      template <typename T>
      common_app(const arg_type<T> &arg, boost::system::error_code &ec)
         : application< application_type<common_application>, accept_stop<yes>, my_application<Application> >(arg, ec)
      {
      }
   };

}} // boost::application

#endif // BOOST_APPLICATION_APPLICATION_HPP
