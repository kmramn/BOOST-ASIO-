// server_application_impl.hpp -----------------------------------------------//
// -----------------------------------------------------------------------------

// Copyright 2011-2012 Renato Tegon Forti

// Distributed under the Boost Software License, Version 1.0.
// See http://www.boost.org/LICENSE_1_0.txt

// -----------------------------------------------------------------------------

// Revision History
// 31-01-2012 dd-mm-yyyy - Initial Release
// 14-09-2013 dd-mm-yyyy - Refactoring

// -----------------------------------------------------------------------------

#ifndef BOOST_APPLICATION_SERVER_APPLICATION_IMPL_HPP
#define BOOST_APPLICATION_SERVER_APPLICATION_IMPL_HPP

#include <boost/lambda/lambda.hpp>
#include <boost/application/application_ctrl.hpp>
#include <boost/application/impl/posix/limit_single_instance_impl.hpp>

#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>

#include <syslog.h>
#include <fcntl.h>
#include <sys/resource.h>

#include <sys/stat.h>

namespace boost { namespace application {

   class server_application_impl : public application_ctrl
   {
   public:

      // constructors, etc.

      // throw version
      template <typename T>
      server_application_impl(const arg_type<T> &args, 
                              const application_ctrl::main_mtd& main, 
                              const application_ctrl::insc_mtd& single_instance,
                              const application_ctrl::inst_mtd& limit_single_instance,
                              const application_ctrl::ctrl_mtd& accept_pause,
                              const application_ctrl::ctrl_mtd& pause, 
                              const application_ctrl::ctrl_mtd& resume, 
                              const application_ctrl::ctrl_mtd& accept_stop,
                              const application_ctrl::ctrl_mtd& stop,
                              const application_ctrl::stup_mtd& setup)
         : application_ctrl(args, main, single_instance, limit_single_instance, accept_pause, pause, resume, accept_stop, stop, setup)
         , ignore_wait_for_termination_request_(false)
      {
         boost::system::error_code ec;

         argv_ = args.get();
         prepare_server_application(ec);

         if(ec)
         {
            BOOST_APPLICATION_THROW_LAST_SYSTEM_ERROR("prepare_server_application() failed");
         }
      }

      // ec version.
      template <typename T>
      server_application_impl(const arg_type<T> &args, 
                              const application_ctrl::main_mtd& main, 
                              const application_ctrl::insc_mtd& single_instance,
                              const application_ctrl::inst_mtd& limit_single_instance,
                              const application_ctrl::ctrl_mtd& accept_pause,
                              const application_ctrl::ctrl_mtd& pause, 
                              const application_ctrl::ctrl_mtd& resume, 
                              const application_ctrl::ctrl_mtd& accept_stop,
                              const application_ctrl::ctrl_mtd& stop,
                              const application_ctrl::stup_mtd& setup,
                              boost::system::error_code &ec)
         : application_ctrl(args, main, single_instance, limit_single_instance, accept_pause, pause, resume, accept_stop, stop, setup)
         , ignore_wait_for_termination_request_(false)
      {
         argv_ = args.get();
         prepare_server_application(ec);
      }

      int run()
      {
         if(ignore_wait_for_termination_request_ == false) {
            state_ = application_running;
         }
	  
         std::vector< string_type > args;

         for (int i = 0; i < argc(); ++i)
         {
            args.push_back(argv()[i]);
         }

         result_code_ = main_(args, *this);
	  
         return result_code_;  
      }

      application_run_type run_type()
      {
         return application_server;
      }

      void wait_for_termination_request(void)
      {
         if(ignore_wait_for_termination_request_)
            return; // we will don't block

         // Wait for stop signal, and then terminate
         sigset_t sset;

         sigemptyset(&sset);

         sigaddset(&sset, SIGINT);
         sigaddset(&sset, SIGQUIT);
         sigaddset(&sset, SIGTERM);

         sigprocmask(SIG_BLOCK, &sset, NULL);

         int sig;
         sigwait(&sset, &sig);

         stop();	
      }

   protected:
      
      // initialize application enviroment
      void prepare_server_application(boost::system::error_code &ec)
      {  
         if(instance_ == NULL)
         {
            instance_ = this;
         }

         // get full module path name
         module_path_name(ec);

         if(ec)
         {
            return; // error
         }

         // we use limit_single_instance_ctrl to create a 
         // mutex on process, to check if we aready have 
         // any istance running, based on uuid defined 
         // by user on functor class
         uuids::uuid single_instance_id(limit_single_instance_());

         if(single_instance_id.is_nil() == false)
         {
            string_type my_app_uuid = 
               boost::lexical_cast<string_type>(single_instance_id);

            limit_single_instance_ctrl::instance().lock(my_app_uuid, ec);

            if(ec)
            {
               return; // error
            }

            if(limit_single_instance_ctrl::instance().is_another_instance_running())
            {	
               if(single_instance_(*this))
               {
                  // we need ignore wait_for_termination_request
                  ignore_wait_for_termination_request_ = true;
                  state_ = application_stoped; 

                  return;
               }
            }
         }

         // call setup application
         if(setup_(*this) == 1)
         {
            // if setup_ returns 
            // installation or un-installation requested 
            // this is not a server execution, exit...

            return;

         } // else continue...

         // need check this
         process_id_ = (unsigned int) daemonize(argc(), argv(), ec);

         signal(SIGABRT, &sighandler);
         signal(SIGTERM, &sighandler);
         signal(SIGINT,  &sighandler);

      }

      // returns a reference to the server_application_impl
      static server_application_impl& instance()
      {
         return *instance_;
      }

      void module_path_name(boost::system::error_code &ec)
      {
         char_type resolved_path[PATH_MAX];

         // realpath -returns the canonicalized absolute pathname
         if (realpath (command_.c_str(), resolved_path) == 0) 
         { 
            BOOST_APPLICATION_SET_LAST_SYSTEM_ERROR(ec);
         } 
         else 
         {
            module_path_name_ = string_type(resolved_path);
         }
      }

      static void sighandler(int signal)
      {
         static_cast<server_application_impl*>(&instance())->stop();
      }

      pid_t daemonize(int argc, char_type** argv, boost::system::error_code &ec)
      {
         // std::cout << "daemonize" << std::endl;

         pid_t pid;

         struct rlimit rl;
         struct sigaction sa;

         // Clear file creation mask.
         umask(0);

         // Get maximum number of file descriptors.
         if (getrlimit(RLIMIT_NOFILE, &rl) < 0)
         {
            // can't getrlimit 
            BOOST_APPLICATION_SET_LAST_SYSTEM_ERROR(ec);
         }

         // Become a session leader to lose controlling TTY.

         if ((pid = fork()) < 0)
         {
            // can't fork
            BOOST_APPLICATION_SET_LAST_SYSTEM_ERROR(ec);
         }
         else if (pid != 0) 
         {
            exit(0); // parent exits
         }

         // Chield continues 

         // Obtain a new process group
         setsid(); 

         // Ensure future opens won't allocate controlling TTYs.

         sa.sa_handler = SIG_IGN;
         sigemptyset(&sa.sa_mask);
         sa.sa_flags = 0;

         if (sigaction(SIGHUP, &sa, NULL) < 0)
         {
            // can't ignore SIGHUP
           BOOST_APPLICATION_SET_LAST_SYSTEM_ERROR(ec);
         }

         if ((pid = fork()) < 0)
         {
            // can't fork
            BOOST_APPLICATION_SET_LAST_SYSTEM_ERROR(ec);
         }
         else if (pid != 0) // parent 
         {
            exit(0);
         }

         //
         // Change the current working directory to the root so
         // we won't prevent file systems from being unmounted.
         if (chdir("/") < 0)
         {
            // can't change directory to /
            BOOST_APPLICATION_SET_LAST_SYSTEM_ERROR(ec);
         }

         // Close all open file descriptors.
         if (rl.rlim_max == RLIM_INFINITY)
         {
            rl.rlim_max = 1024;
         }

         for (int i = 0; i < (int)rl.rlim_max; i++)
         {
            close(i);
         }

         // Attach file descriptors 0, 1, and 2 to /dev/null.

         int fd0, fd1, fd2;

         fd0 = open("/dev/null", O_RDWR);
         fd1 = dup(0);
         fd2 = dup(0);

         if (fd0 != 0 || fd1 != 1 || fd2 != 2) 
         {
            // todo
            //BOOST_THROW_EXCEPTION(
            //   server_application_error(
             //     "unexpected file descriptors %d %d %d", -1));
         } 

         return pid;
      }


      // Get argc
      int argc() const
      {
         return argv_.size();
      }

      // Get argv
      char_type** argv() 
      {
         return &argv_[0];
      }

      //
      // handlers
      //

      void stop()
      {
         if(!accept_stop_())
            return;

         if(stop_() == 1)
         {
            state_ = application_stoped;
         }
      }

   private:
      
      // used in single instance 
      bool ignore_wait_for_termination_request_;

      // our args vector
      std::vector<application_ctrl::char_type*> argv_;

      static server_application_impl* instance_;

   };

   // The unique instance of common application (Windows )
   server_application_impl* server_application_impl::instance_ = 0;

	
}} // boost::application 

#endif // BOOST_APPLICATION_SERVER_APPLICATION_IMPL_HPP

