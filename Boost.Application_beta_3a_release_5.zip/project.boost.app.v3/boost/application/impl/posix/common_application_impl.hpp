//  application_impl.hpp  ---------------------------------------------------//
// -----------------------------------------------------------------------------

//  Copyright 2011-2012 Renato Tegon Forti

//  Distributed under the Boost Software License, Version 1.0.
//  See http://www.boost.org/LICENSE_1_0.txt

// -----------------------------------------------------------------------------

// Revision History
// 06-01-2012 dd-mm-yyyy - Initial Release
// 12-08-2013 dd-mm-yyyy - Refactoring

// -----------------------------------------------------------------------------

#ifndef BOOST_APPLICATION_COMMON_APPLICATION_IMPL_HPP
#define BOOST_APPLICATION_COMMON_APPLICATION_IMPL_HPP

#include <signal.h>
#include <stdlib.h>
#include <errno.h>

#include <boost/application/application_ctrl.hpp>
#include <boost/application/impl/posix/limit_single_instance_impl.hpp>

namespace boost { namespace application {

   class common_application_impl : public application_ctrl
   {

   public:
      
      // constructors, etc.

      // throw version
      template <typename T>
      common_application_impl(const arg_type<T> &args, 
                              const application_ctrl::main_mtd& main, 
                              const application_ctrl::insc_mtd& single_instance,
                              const application_ctrl::inst_mtd& limit_single_instance,
                              const application_ctrl::ctrl_mtd& accept_pause,
                              const application_ctrl::ctrl_mtd& pause, 
                              const application_ctrl::ctrl_mtd& resume, 
                              const application_ctrl::ctrl_mtd& accept_stop,
                              const application_ctrl::ctrl_mtd& stop,
                              const application_ctrl::stup_mtd& setup)
         : application_ctrl(args, main, single_instance, limit_single_instance, accept_pause, pause, resume, accept_stop, stop, setup)
         , setup_enabled_(false)
         , ignore_wait_for_termination_request_(false)
      {
         boost::system::error_code ec;
         prepare_common_application(ec);

         if(ec)
         {
            BOOST_APPLICATION_THROW_LAST_SYSTEM_ERROR("prepare_common_application() failed");
         }
      }

      // ec version.
      template <typename T>
      common_application_impl(const arg_type<T> &args, 
                              const application_ctrl::main_mtd& main, 
                              const application_ctrl::insc_mtd& single_instance,
                              const application_ctrl::inst_mtd& limit_single_instance,
                              const application_ctrl::ctrl_mtd& accept_pause,
                              const application_ctrl::ctrl_mtd& pause, 
                              const application_ctrl::ctrl_mtd& resume, 
                              const application_ctrl::ctrl_mtd& accept_stop,
                              const application_ctrl::ctrl_mtd& stop,
                              const application_ctrl::stup_mtd& setup,
                              boost::system::error_code &ec)
         : application_ctrl(args, main, single_instance, limit_single_instance, accept_pause, pause, resume, accept_stop, stop, setup)
         , setup_enabled_(false)
         , ignore_wait_for_termination_request_(false)
      {
         prepare_common_application(ec);
      }

      virtual ~common_application_impl()
      {
      }

      int run()
      {
         if(setup_enabled_)
            return 0;
		 
         if(ignore_wait_for_termination_request_ == false) {
            state_ = application_running;
         }

         std::vector< string_type > args;

         for (int i = 0; i < argc(); ++i)
         {
            args.push_back(argv()[i]);
         }

         result_code_ = main_(args, *this);
      
         return result_code_;  
      }

      application_run_type run_type()
      {
         return application_common;
      }

      void wait_for_termination_request(void)
      {		

         if(ignore_wait_for_termination_request_)
            return; // we will don't block

         sigset_t sset;

         sigemptyset(&sset);

         sigaddset(&sset, SIGINT);
         sigaddset(&sset, SIGQUIT);
         sigaddset(&sset, SIGTERM);

         sigprocmask(SIG_BLOCK, &sset, NULL);

         int sig;
         sigwait(&sset, &sig);

         stop();		
      }

   protected:

      // initialize application enviroment
      void prepare_common_application(boost::system::error_code &ec)
      {     
         if(instance_ == NULL)
         {
            instance_ = this;
         }    

         // we use limit_single_instance_ctrl to create a 
         // mutex on process, to check if we aready have 
         // any istance running, based on uuid defined 
         // by user on functor class
         uuids::uuid single_instance_id(limit_single_instance_());

         if(single_instance_id.is_nil() == false)
         {
            string_type my_app_uuid = 
               boost::lexical_cast<string_type>(single_instance_id);

            limit_single_instance_ctrl::instance().lock(my_app_uuid, ec);

            if(ec)
            {
               return; // error
            }

            if(limit_single_instance_ctrl::instance().is_another_instance_running())
            {	
               if(single_instance_(*this))
               {
                  // we need ignore wait_for_termination_request
                  ignore_wait_for_termination_request_ = true;
                  state_ = application_stoped; 
                  return;
               }
            }
         }

         signal(SIGABRT, &sighandler);
         signal(SIGTERM, &sighandler);
         signal(SIGINT,  &sighandler);

         module_path_name(ec);
         
         if(ec)
         {
            return; // error
         }

         process_id_ = (unsigned int) getpid();

         // call setup application
         if(setup_(*this) == 1)
         {
            // if setup_ returns true, on run we will exit
            setup_enabled_ = true;

         } // else continue...
      }

      // returns a reference to the server_application_impl
      static common_application_impl& instance()
      {
         return *instance_;
      }

      void module_path_name(boost::system::error_code &ec)
      {
         char_type resolved_path[PATH_MAX];

         // realpath -returns the canonicalized absolute pathname
         if (realpath (command_.c_str(), resolved_path) == 0) 
         { 
            BOOST_APPLICATION_SET_LAST_SYSTEM_ERROR(ec);
         } 
         else 
         {
            module_path_name_ = string_type(resolved_path);
         }
      }

      static void sighandler(int signal)
      {
         static_cast<common_application_impl*>(&instance())->stop();
      }

      //
      // Handlers
      //

      void stop()
      {
         if(!accept_stop_())
            return;

         if(stop_() == 1)
         {
            state_ = application_stoped;
         }
      }

   private:
      
      // our single instance, we can have only 1 obj of this class
      // in process instance
      static common_application_impl* instance_;

      // flag to ctrl setup
      bool setup_enabled_;

      // used in single instance 
      bool ignore_wait_for_termination_request_;

   };

   // The unique instance of common application (unix)
   common_application_impl* common_application_impl::instance_ = 0;

	
}} // boost::application 

#endif // BOOST_APPLICATION_COMMON_APPLICATION_IMPL_HPP

