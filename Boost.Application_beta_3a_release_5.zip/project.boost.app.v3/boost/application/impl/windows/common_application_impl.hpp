//  application_impl.hpp  ---------------------------------------------------//
// -----------------------------------------------------------------------------

//  Copyright 2011-2013 Renato Tegon Forti

//  Distributed under the Boost Software License, Version 1.0.
//  See http://www.boost.org/LICENSE_1_0.txt

// -----------------------------------------------------------------------------

// Revision History
// 03-02-2012 dd-mm-yyyy - Initial Release
// 12-08-2013 dd-mm-yyyy - Refactoring

// -----------------------------------------------------------------------------

#ifndef BOOST_APPLICATION_COMMON_APPLICATION_IMPL_HPP
#define BOOST_APPLICATION_COMMON_APPLICATION_IMPL_HPP

// application
#include <boost/application/application_ctrl.hpp>
#include <boost/application/impl/windows/limit_single_instance_impl.hpp>

#ifdef BOOST_MSVC
#  pragma warning(push)
#  pragma warning(disable : 4251 4231 4660)
#endif
 
namespace boost { namespace application {

   // This class hold specific OS implementation of common application.
   // [ Windows Version ]
   class common_application_impl : public application_ctrl
   {
   public:

      // constructors, etc.

      // throw version
      template <typename T>
      common_application_impl(const arg_type<T> &args, 
                              const application_ctrl::main_mtd& main, 
                              const application_ctrl::insc_mtd& single_instance,
                              const application_ctrl::inst_mtd& limit_single_instance,
                              const application_ctrl::ctrl_mtd& accept_pause,
                              const application_ctrl::ctrl_mtd& pause, 
                              const application_ctrl::ctrl_mtd& resume, 
                              const application_ctrl::ctrl_mtd& accept_stop,
                              const application_ctrl::ctrl_mtd& stop,
                              const application_ctrl::stup_mtd& setup)
         : application_ctrl(args, main, single_instance, limit_single_instance, accept_pause, pause, resume, accept_stop, stop, setup)
         , setup_enabled_(false)
         , ignore_wait_for_termination_request_(false)
      {
         boost::system::error_code ec;
         prepare_common_application(ec);

         if(ec)
         {
            BOOST_APPLICATION_THROW_LAST_SYSTEM_ERROR("prepare_common_application() failed");
         }
      }

      // ec version.
      template <typename T>
      common_application_impl(const arg_type<T> &args, 
                              const application_ctrl::main_mtd& main, 
                              const application_ctrl::insc_mtd& single_instance,
                              const application_ctrl::inst_mtd& limit_single_instance,
                              const application_ctrl::ctrl_mtd& accept_pause,
                              const application_ctrl::ctrl_mtd& pause, 
                              const application_ctrl::ctrl_mtd& resume, 
                              const application_ctrl::ctrl_mtd& accept_stop,
                              const application_ctrl::ctrl_mtd& stop,
                              const application_ctrl::stup_mtd& setup,
                              boost::system::error_code &ec)
         : application_ctrl(args, main, single_instance, limit_single_instance, accept_pause, pause, resume, accept_stop, stop, setup)
         , setup_enabled_(false)
         , ignore_wait_for_termination_request_(false)
      {
         prepare_common_application(ec);
      }

      virtual ~common_application_impl()
      {
         terminate();
      }

      int run()    
      {
         if(setup_enabled_)
            return 0;

         if(ignore_wait_for_termination_request_ == false) 
         {
            state_ = application_running;
         }

         std::vector< string_type > args;

         for (int i = 0; i < argc(); ++i)
         {
            args.push_back(argv()[i]);
         }

         // block and waits the user logic to be executed.
         result_code_ = main_(args, *this);
          
         // return result, user can get result using method 
         // result_code on ctrl class too.
         return result_code_;          
      }

      application_run_type run_type()
      {
         return application_common;
      }

      // wait_for_termination_request exposed to client interface
      void wait_for_termination_request(void)
      {
         if(ignore_wait_for_termination_request_)
            return; // we will don't block

         // Wait for stop signal, and then terminate
         WaitForSingleObject(terminate_event_, INFINITE);
      }

   protected:

      // initialize application enviroment
      void prepare_common_application(boost::system::error_code &ec)
      {     
         if(instance_ == NULL)
         {
            instance_ = this;
         }    
         
         // assume no error

         result_code_ = 0;
         terminate_event_ = NULL;

         // we use limit_single_instance_ctrl to create a 
         // mutex on process, to check if we aready have 
         // any istance running, based on uuid defined 
         // by user on functor class
         uuids::uuid single_instance_id(limit_single_instance_());

         if(single_instance_id.is_nil() == false)
         {
            string_type my_app_uuid = 
               boost::lexical_cast<string_type>(single_instance_id);

            limit_single_instance_ctrl::instance().lock(my_app_uuid, ec);

            if(ec)
            {
               return; // error
            }

            if(limit_single_instance_ctrl::instance().is_another_instance_running())
            {	
               if(single_instance_(*this))
               {
                  // we need ignore wait_for_termination_request
                  ignore_wait_for_termination_request_ = true;
                  state_ = application_stoped; 
                  return;
               }
            }
         }

         // get full module path name
         module_path_name(ec);

         if(ec)
         {
            return; // error
         }

         // Get process id (PID)
         process_id_ = (unsigned int) GetCurrentProcessId();

         // create the termination event
         terminate_event_ = CreateEvent (0, TRUE, FALSE, 0);

         if(SetConsoleCtrlHandler(console_ctrl_handler, TRUE) == 0)
         {
            BOOST_APPLICATION_SET_LAST_SYSTEM_ERROR(ec);
            return; // error
         }

         // call setup application
         if(setup_(*this) == 1)
         {
            // if setup_ returns true, on run we will exit
            setup_enabled_ = true;

         } // else continue...
      }

      // returns a reference to the server_application_impl
      static common_application_impl& instance()
      {
         return *instance_;
      }

      // Get module path name
      void module_path_name(boost::system::error_code &ec)
      {
         char_type module_name[MAX_PATH];

         if (GetModuleFileName(0, module_name, sizeof(module_name)) > 0)			
         {
            module_path_name_ = string_type(module_name); 
         }
         else
         {
            BOOST_APPLICATION_SET_LAST_SYSTEM_ERROR(ec);
         }     
      }

      // console_ctrl_handler to cach signals
      static BOOL WINAPI console_ctrl_handler(DWORD ctrl_type)
      {
         switch (ctrl_type) 
         { 
            case CTRL_C_EVENT: 
            case CTRL_CLOSE_EVENT: 
            case CTRL_BREAK_EVENT:
            {
               static_cast<common_application_impl*>(&instance())->stop(); 
               return TRUE;
            }
            default: 
            {
               return FALSE; 
            }
         }
      }

      //
      // Handlers
      //

      void stop()
      {
         if(!accept_stop_())
            return;

         if(stop_() == 1)
         {
            state_ = application_stoped;

            // Set the event that is holding main
            // so that main can return
            SetEvent(terminate_event_);	
         }
      }

      void terminate(void)
      {
         // if terminateEvent has been created, close it.
         if (terminate_event_)
         {
            CloseHandle(terminate_event_);
         }
      }

   private:

      // our single instance, we can have only 1 obj of this class
      // in process instance
      static common_application_impl* instance_;

      // Terminate event ctrl
      HANDLE terminate_event_;
      
      // flag to ctrl setup
      bool setup_enabled_;

      // used in single instance 
      bool ignore_wait_for_termination_request_;

   };

   // The unique instance of common application (Windows )
   common_application_impl* common_application_impl::instance_ = 0;

}} // boost::application 

#ifdef BOOST_MSVC
#pragma warning(pop)
#endif

#endif // BOOST_APPLICATION_COMMON_APPLICATION_IMPL_HPP
